class DirNode:
    def __init__(self, dirname: str):
        self.dirname = dirname
        self.permission = None
        self.dir_dict = {}
        self.node = 1
        self.next = None
        self.lock_read = 0
        self.lock_write = 0
        self.content = ''
        self.prevdir = None
