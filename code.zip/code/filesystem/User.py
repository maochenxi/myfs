class User:
    def __init__(self,name):
        self.cwd = b'/'
        self.username = name
        self.Node = None
        self.group = None