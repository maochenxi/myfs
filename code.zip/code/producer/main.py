import sys
import threading  # 导入多线程模块
import time  # 导入时间模块
import traceback

from PyQt5.QtWidgets import QApplication, QMainWindow, QListWidgetItem, QMessageBox
from PyQt5.QtCore import QThread, QWaitCondition, QMutex, pyqtSignal
from ui import *

produce_sum = 0
consume_sum = 0
producer_dict = {}
consumer_dict = {}
produce_speed = 0
consume_speed = 0
app = None
buffer = None



class App(QMainWindow, Ui_Dialog):
    def __init__(self, parent=None):
        super(App, self).__init__(parent)
        self.setupUi(self)
        # 输入参数
        self.lineEdit_4.textChanged.connect(self.proname)
        self.lineEdit_5.textChanged.connect(self.coname)
        self.lineEdit_6.textChanged.connect(self.pronum)
        self.lineEdit_7.textChanged.connect(self.conum)
        # 按钮事件
        self.pushButton.clicked.connect(self.addpro)
        self.pushButton_2.clicked.connect(self.decpro)
        self.pushButton_3.clicked.connect(self.respro)
        self.pushButton_4.clicked.connect(self.pausepro)
        self.pushButton_5.clicked.connect(self.pausecon)
        self.pushButton_6.clicked.connect(self.deccon)
        self.pushButton_7.clicked.connect(self.rescon)
        self.pushButton_8.clicked.connect(self.addcon)
        self.pushButton_9.clicked.connect(self.prosp)
        self.pushButton_10.clicked.connect(self.consp)
        self.pushButton_11.clicked.connect(self.totalpro)
        self.pushButton_12.clicked.connect(self.totalcon)
        self.pushButton_13.clicked.connect(self.start)
        self.pushButton_14.clicked.connect(self.showProducerSpeed)
        self.pushButton_15.clicked.connect(self.showConsumerSpeed)
        self.pushButton_16.clicked.connect(self.change_buffer_size)
        self.producer_num = 0
        self.consumer_num = 0
        self.produce_name = ''
        self.consume_name = ''
    def change_buffer_size(self):
        global buffer
        new_size = self.lineEdit_11.text()
        self.lineEdit_11.setText('')
        self.label_16.setText(new_size)
        new_size = int(new_size)
        x = new_size - buffer.Buffer_size
        buffer.Buffer_size = new_size
        for i in range(0,x):
            buffer.Buffer_.append(0)
        # print(len(buffer.Buffer_))
    def showProducerSpeed(self):
        proname = self.comboBox.currentText()
        #print(proname)
        curspeed = producer_dict[proname].speed
        #print(curspeed)
        self.lineEdit.setText(str(curspeed))
        #print("13234235423")
    def showConsumerSpeed(self):
        proname = self.comboBox_2.currentText()
        curspeed = consumer_dict[proname].speed
        self.lineEdit_2.setText(str(curspeed))
        #self.lineEdit_2.
    def pronum(self):
        self.comboBox.clear()
        global produce_speed, producer_dict,buffer
        if self.lineEdit_6.text().isdigit():
            self.buffer_size = int(self.lineEdit_9.text())
            self.producer_num = int(self.lineEdit_6.text())
            produce_speed = int(self.lineEdit_8.text())
            for i in range(self.producer_num):
                name = '[生产者-' + str(i + 1) + ']'
                p = Producer(name, produce_speed)
                producer_dict[name] = p
                self.comboBox.addItem(name)
    def conum(self):
        self.comboBox_2.clear()
        global consume_speed, consumer_dict
        if self.lineEdit_7.text().isdigit():
            self.consumer_num = int(self.lineEdit_7.text())
            consume_speed = int(self.lineEdit_8.text())
            for i in range(self.consumer_num):
                name = '[消费者-' + str(i + 1) + ']'
                c = Consumer(name, consume_speed)
                consumer_dict[name] = c
                self.comboBox_2.addItem(name)
    def prosp(self):
        proname = self.comboBox.currentText()
        if self.lineEdit.text().isdigit():
            p = producer_dict[proname]
            p.speed = int(self.lineEdit.text())
        else:
            QMessageBox(text="输入必须是数字").show()
        self.lineEdit.setText('')
    def consp(self):
        proname = self.comboBox_2.currentText()
        if self.lineEdit_2.text().isdigit():
            p = consumer_dict[proname]
            p.speed = int(self.lineEdit_2.text())
        else:
            QMessageBox(text="输入必须是数字").show()
        self.lineEdit_2.setText('')
    def addpro(self):
        addProducer(self.produce_name)
        self.comboBox.addItem(self.produce_name)
        self.lineEdit_4.setText('')
        self.lineEdit.setText('')
    def addcon(self):
        addConsumer(self.consume_name)
        self.comboBox_2.addItem(self.consume_name)
        self.lineEdit_5.setText('')
        self.lineEdit_2.setText('')
    def decpro(self):
        reduce(self.comboBox.currentText(), 'producer')
        self.comboBox.removeItem(self.comboBox.currentIndex())
        self.lineEdit_4.setText('')
        self.lineEdit.setText('')
    def deccon(self):
        reduce(self.comboBox_2.currentText(), 'consumer')
        self.comboBox_2.removeItem(self.comboBox.currentIndex())
        self.lineEdit_5.setText('')
        self.lineEdit_2.setText('')
    def coname(self):
        self.consume_name = self.lineEdit_5.text()
    def proname(self):
        self.produce_name = self.lineEdit_4.text()
    def pausepro(self):
        pause(self.comboBox.currentText(), 'producer')
    def pausecon(self):
        pause(self.comboBox_2.currentText(), 'consumer')
    def respro(self):
        resume(self.comboBox.currentText(), 'producer')
    def rescon(self):
        resume(self.comboBox_2.currentText(), 'consumer')
    def totalpro(self):
        global produce_sum
        self.label_8.setText(str(produce_sum))
    def totalcon(self):
        global consume_sum
        self.label_9.setText(str(consume_sum))
    def start(self):
        global consumer_dict, producer_dict,buffer
        # print(consumer_dict)
        buffer = Buffer(self.buffer_size)
        self.label_16.setText(str(self.buffer_size))
        for i in consumer_dict.keys():
            consumer_dict[i].start()
            # print(i)
        for i in producer_dict.keys():
            producer_dict[i].start()
        # print(consumer_dict)


class Buffer():
    def __init__(self, buffer_size):
        self.Buffer_ = []
        self.Buffer_point = 0
        self.Buffer_size = buffer_size
        self.Condition = threading.Condition()  # 创建条件对象
        for i in range(buffer_size):
            self.Buffer_.append(0)


    def produce(self):
        if self.Buffer_point == self.Buffer_size:
            return -1
        else:
            self.Buffer_[self.Buffer_point] = 1
            self.Buffer_point += 1
            return self.Buffer_point

    def consume(self):
        if self.Buffer_point == 0:
            return -1
        else:
            self.Buffer_point -= 1
            self.Buffer_[self.Buffer_point] = 0
            return self.Buffer_point


# 创建生产者线程类
class Producer(QThread):
    def __init__(self, threadName, speed):  # 构造方法
        super().__init__()
        self.threadName = threadName
        self.speed = speed
        self.object = 0
        #self.mEvent = threading.Event()
        #self.stop = 0
        self.status = ''
        self._isPause = False
        self.cou = 0

    def run(self):
        global produce_sum, mapp
        while True:
            if (is_current_pro(self.threadName)):
                mapp.label_24.setText(str(self.cou))
            if self._isPause:
                if (is_current_pro(self.threadName)):
                    mapp.label_18.setText("暂停状态")
                continue
            else:
                if (is_current_pro(self.threadName)):
                    mapp.label_18.setText("生产状态")
            if self.object == 0:
                QThread.sleep(self.speed)
                self.object = 1
            if buffer.Condition.acquire():  # 加锁,相当于调用Condition绑定的Lock的acquire()
                print(self.threadName+"获得了锁定")
                #QThread.sleep(self.speed * 1000)
                count = self.produce()
                if count == -1:  # 判断共享变量是否已达到上限
                    msg = "共享区已满，生产者"+self.threadName+"线程进入阻塞Block状态，停止放入！"
                    mapp.listWidget.addItem(QListWidgetItem(msg))
                    if (is_current_pro(self.threadName)):
                        mapp.label_18.setText("阻塞状态")
                    buffer.Condition.wait()  # 当前线程进入阻塞状态
                else:
                    msg = time.ctime() + ' 生产者' + self.threadName + '生产了1件商品放入共享区，共享区商品总数: ' + str(count)
                    mapp.listWidget.addItem(QListWidgetItem(msg))
                    mapp.lineEdit_10.setText(str(count))
                    produce_sum += 1
                    self.cou += 1
                    self.object = 0
                    buffer.Condition.notify()  # 从waiting池中挑选一个线程，唤醒waiting状态的线程
                buffer.Condition.release()  # 解除锁定
            else:
                print(self.threadName + "没有获得锁，互斥")

    def produce(self):
        return buffer.produce()

    def pause(self):
        self._isPause = True
        # self.mEvent.clear()

    def resume(self):
        self._isPause = False
        # self.mEvent.set()

# 消费者线程类
class Consumer(QThread):
    def __init__(self, threadName, speed):  # 构造方法
        # threading.Thread.__init__(self)
        super().__init__()
        self.threadName = threadName
        self.speed = speed
        # self.mEvent = threading.Event()
        # self.stop = 0
        self._isPause = False
        self.status = ''
        self.cou = 0

    def run(self):
        global consume_sum, mapp
        while True:
            if (is_current_con(self.threadName)):
                mapp.label_22.setText(str(self.cou))
            if self._isPause:
                if (is_current_con(self.threadName)):
                    mapp.label_20.setText("暂停状态")
                continue
            if (is_current_con(self.threadName)):
                mapp.label_20.setText("消费状态")
            if buffer.Condition.acquire():  # 使用条件对象获取锁并锁定
                print(self.threadName+"获得了锁定")
                count = self.consume()
                if count == -1:  # 判断共享变量是否为空
                    msg = "共享区已空，消费者"+self.threadName+"线程进入阻塞Block状态，停止获取！"
                    mapp.listWidget_2.addItem(QListWidgetItem(msg))
                    if (is_current_con(self.threadName)):
                        mapp.label_20.setText("阻塞状态")
                    buffer.Condition.wait()  # 当前线程进入阻塞状态

                else:
                    msg = time.ctime() + ' 消费者' + self.threadName + '消费了一件商品，共享区商品总数: ' + str(count)
                    mapp.listWidget_2.addItem(QListWidgetItem(msg))
                    mapp.lineEdit_10.setText(str(count))
                    consume_sum += 1
                    self.cou += 1
                    buffer.Condition.notify()  # 唤醒线程
                    QThread.sleep(self.speed)
                buffer.Condition.release()  # 解除锁定
            else:
                print(self.threadName+"没有获得锁，互斥")

    def consume(self):
        return buffer.consume()

    def pause(self):
        self._isPause = True
        # self.mEvent.clear()

    def resume(self):
        self._isPause = False
        # self.mEvent.set()

def is_current_pro(proname):
    global mapp
    curname = mapp.comboBox.currentText()
    if(proname == curname):
        return 1
    return 0

def is_current_con(conname):
    global mapp
    curname = mapp.comboBox_2.currentText()
    if(conname == curname):
        return 1
    return 0


def addProducer(name):
    global producer_dict, produce_speed
    p = Producer(name,produce_speed)
    p.start()
    producer_dict[name] = p


def addConsumer(name):
    global consumer_dict, consume_speed
    c = Consumer(name, consume_speed)
    c.start()
    consumer_dict[name] = c


def pause(name, types):
    # p = None
    if types == 'consumer':
        global consumer_dict
        for x in consumer_dict.keys():
            if x == name:
                consumer_dict[x].pause()
                break
    if types == 'producer':
        global producer_dict
        for x in producer_dict.keys():
            if x == name:
                producer_dict[x].pause()
                break


def resume(name, type):
    p = None
    if type == 'consumer':
        global consumer_dict
        for x in consumer_dict.keys():
            if x == name:
                p = consumer_dict[x]
                break
    if type == 'producer':
        global producer_dict
        for x in producer_dict.keys():
            if x == name:
                p = producer_dict[x]
                break
    p.resume()


def reduce(name, type):
    if type == 'consumer':
        for x in consumer_dict.keys():
            if x == name:
                consumer_dict[x].pause()
                consumer_dict.pop(x)
                break
    if type == 'producer':
        for x in producer_dict:
            if x == name:
                producer_dict[x].pause()
                producer_dict.pop(x)
                break


if __name__ == '__main__':

    app = QApplication(sys.argv)
    global mapp
    mapp = App()
    mapp.show()
    sys.exit(app.exec_())

